<?php

include '../src/Tasks.php';
require '../src/xajax_core/xajax.inc.php';

$service = new Google_Service_Tasks($client);

$xajax = new xajax('../src/Tools.php');
$xajax->register(XAJAX_FUNCTION, 'ordenarEnvios');

$xajax->configure('javascript URI', '../src/');
$xajax->configure('debug', false);
$xajax->processRequest();

// función que calcula si la fecha es mayor, menor o igual que la fecha actual
// 1 mayor que hoy, 0 igual, -1 menor
function esMayor($fechain){    
    $fecha = strtotime($fechain);
    $hoy = getdate();
    $hoydma = date("Y-m-d", mktime(0, 0, 0, $hoy['mon'], $hoy['mday'], $hoy['year']));
    $fechahoy = strtotime($hoydma);
    $res = ($fecha > $fechahoy) ? 1 : (($fecha < $fechahoy) ? -1 : 0);
    return $res;
}

// función que comprueba si la lista ya existe
// lo he comprobado mirando si ya existe el título
// devuelve 1 si  ya existe, 0 en caso contrario
function existeTitulo($array,$titulo){        
    $existe = 0;
    if (!empty($array)){                    
        foreach ($array as $item) {                    
            if($item['title'] == $titulo){
                $existe++;
                break;                        
            }                        
        }
    }
    return $existe;        
}

// Ya estaba, devuelve la lista de tareas
function getListasTareas()
{
    global $service;
    $optParams = ['maxResults' => 100];
    $results = $service->tasklists->listTasklists($optParams);
    return $results;
}

// Ya estaba, devuelve las tareas de la lista con el id pasado por parámetro
function getTareas($id)
{
    global $service;
    $res1 = $service->tasks->listTasks($id);
    return $res1;
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">    
    <!-- Jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Repartos</title>
    <?php $xajax->printJavascript(); ?>
    <!-- funciones javascript que usaremos -->
    <script src="../js/funciones.js"></script>
</head>

<body style="background:#00bfa5;">
<?php
// Viene de la pantalla de envios
if (isset($_POST['lat'])) {
    $note = $_POST['lat'] . "," . $_POST['lon'];
    $title = ucwords($_POST['pro']) . ". " . ucwords($_POST['dir']) . ", Almería. ";
    $idLt = $_POST['idLTarea'];
    unset($_SESSION[$idLt]);
    // guardamos la tarea
    $op = ['title' => $title, 'notes' => $note];
    $tarea = new Google_Service_Tasks_Task($op);
    try {
        $res = $service->tasks->insert($idLt, $tarea);
    } catch (Google_Exception $ex) {
        die("Error al guardar la tarea: " . $ex);
    }
    unset($_POST['lat']);
}
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'blt': // Han pulsado borrar Lista
            try {
                $service->tasklists->delete($_GET['idlt']);
            } catch (Google_Exception $ex) {
                die("Error al borrar la lista de tareas: " . $ex);
            }
            unset($_SESSION[$_GET['idlt']]);
            break;
        case 'bt': // Han pulsado borrar tarea
            try {
                $service->tasks->delete($_GET['idlt'], $_GET['idt']);
            } catch (Google_Exception $ex) {
                die("Error al borrar la tarea: " . $ex);
            }
            unset($_SESSION[$_GET['idlt']]);
            break;
        case 'nlt': // Crea una lista de tareas
            // Aquí vamos a montar el título de la tarea y comprobaremos la fecha
            $titulo = $_GET['title'];
            $opciones = ["title" => $_GET['title']];
            $res = esMayor($titulo); // 1 mayor que hoy, 0 igual, -1 menor
            if($res==-1) // Si es -1 será inferior a la actual
                echo "<script language='javascript'>alert('La fecha no puede ser inferior a la actual.');</script>";
            else{    
                $val = date("d/m/Y", strtotime($titulo));                                
                $titulo = "Repartos ".$val;
                $listas = getListasTareas();
                $res = existeTitulo($listas["items"],$titulo);
                if($res==0){
                    $opciones = ["title" => $titulo];                
                    $taskList = new Google_Service_Tasks_TaskList($opciones);
                    try {
                        $service->tasklists->insert($taskList);
                        // Controlaré lo que devuelva para saber si ya existe
                    } catch (Google_Exception $ex) {
                        die("Error al crear una lista de tareas: " . $ex);
                    }                    
                }
                else
                    echo "<script language='javascript'>alert('La lista ya existe.');</script>";                     
            }
            break;            
        case 'oEnvios': // Si han pulsado ordenar
            $apos = $_GET['pos'];
            $id_lista = $_GET['idLt'];
            $id_listac = $id_lista."c";
            unset($_SESSION['idLt']);            
            //Obtenemos todas las tareas de esta lista de tareas
            $tareas = getTareas($id_lista);
            foreach ($apos as $k => $v) {
                //los envios me los manda ordenados del 1 al n
                //en php los array empiezan por cero, poe eso restamos 1
                //asi el envio 1 pasa a ser el 0, el 2 el 1 ...
                $p = $v - 1;
                $arrayO[$k] = $tareas->getItems()[$p]->getTitle();
                $arrayOC[$k] = $tareas->getItems()[$p]->getNotes();                
            }
            $_SESSION[$id_lista] = $arrayO;   
            $_SESSION[$id_listac] = $arrayOC;
        case 'oculb': // Ocultar la lista, vaciando la variable de sesión con la que se dibuja valdría
            if(isset($_GET['idlt'])){
                $idL = $_GET['idlt'];            
                unset($_SESSION[$idL]);            
            }            
    }
}
?>
<h4 class="text-center mt-3">Gestión de Pedidos</h4>
<div class="container mt-4" style='width:80rem;'>
    <form action='<?php echo $_SERVER['PHP_SELF'] ?>' method='get'>
        <div class="row">
            <div class="col-md-3 mb-2">
                <button type='submit' class="btn btn-info">
                    <i class='fas fa-plus mr-1'></i>Nueva Lista de Reparto
                </button>
            </div>
            <input type='hidden' name='action' value='nlt'>
            <div class="col-md-2">
                <input type=date class="form form-control" id="title" name="title" required>
            </div>
        </div>
    </form>    
    <?php    
    $listas = getListasTareas();
    foreach ($listas->getItems() as $lista) {
        if ($lista->getTitle() == "My Tasks" || $lista->getTitle() == "Mis tareas") continue;
        echo "<table class='table mt-2' id='{$lista->getId()}'>\n";
        echo "<thead class='bg-secondary'>\n";
        echo "<tr>\n";
        echo "<th scope='col' style='width:42rem;'>{$lista->getTitle()}</th>\n";
        echo "<th scope='col' class='text-right'>\n";
        // Al pulsar nuevo vamos a la pantalla de envios
        echo "<a href='envio.php?id={$lista->getId()}' class='btn btn-info mr-2 btn-sm'><i class='fas fa-plus mr-1'></i>Nuevo</a>\n";
        // Botón para ordenar los envíos mediante la funcion ordenarEnvios mediante ajax
        echo "<button class='btn btn-success mr-2 btn-sm' onclick=\"ordenarEnvios('{$lista->getId()}')\"><i class='fas fa-sort mr-1'></i>ordenar</button>\n";
        // Botón para ocultar orden
        echo "<a href='repartos.php?action=oculb&idlt={$lista->getId()}' class='btn btn-warning mr-2 btn-sm'><i class='fa fa-eye-slash mr-1'></i>Ocultar orden</a>\n";    
        // Enlace que borra la Lista
        echo "<a href='repartos.php?action=blt&idlt={$lista->getId()}' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Borrar Lista?')\"><i class='fas fa-trash mr-1'></i>Borrar</a>\n";
        echo "</th></tr>\n";
        echo "</thead>\n";
        echo "<tbody style='font-size:0.8rem'>\n";
        // Procedimiento que lee todas las listas y tareas
        $tareas = getTareas($lista->getId());
        $listaid = $lista->getId();
        foreach ($tareas->getItems() as $tarea) {
            echo "<tr>\n";
            // Titulo de la tarea
            echo "<th scope='row' name='filat{$lista->getId()}'>{$tarea->getTitle()} ({$tarea->getNotes()})\n";
            echo "<input id='nota{$tarea->getId()}' type='hidden' value='{$tarea->getNotes()}'></th>\n";
            // Enlace que borrar la tarea
            echo "<th scope='row' class='text-right'>\n<a href='repartos.php?action=bt&idlt={$lista->getId()}&idt={$tarea->getId()}' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Borrar Tarea?')\">";
            echo "<i class='fas fa-trash mr-1'></i>Borrar</a>\n";
            // Botón que nos mostrará el mapa
            echo "<a href='mapa.php?id={$lista->getId()}&coord={$tarea->getNotes()}' class='btn btn-info ml-2 btn-sm'><i class='fas fa-map mr-1'></i>Mapa</a>\n</th>\n";
            echo "</tr>\n";
        }
        echo "</tbody>\n";
        echo "</table>\n";
        if (isset($_SESSION[$lista->getId()])) {
            echo "<div class='container mt-2 mb-2' style='font-size:0.8rem' id='lista{$lista->getId()}'>";
            echo "<ul class='list-group'>";
            // Nos muestra los elementos de la lista, las tareas
            foreach ($_SESSION[$lista->getId()] as $k => $v) {
                echo "<li class='list-group-item list-group-item-info'>" . ($k + 1) . ".- " . $v . "</li>";
            }                  
            $aux = $lista->getId()."c";          
            $aux1 = $_SESSION[$aux];                        
            // Añado las coordenadas ficticias del almacén como origen y fin de la ruta            
            // Centro Comercial Mediterráneo, Av. del Mediterráneo, S/N, 04009 Almería
            $almacen = "36.85471293584672, -2.447291933969098";
            //Añadir al inicio el almacén
            array_unshift($aux1, $almacen);
            // Añadir al final el almacén
            array_push($aux1, $almacen);            
            $scoord = implode('@',$aux1);
            echo "<input type='hidden' name='scoord' value='nlt'>";
            echo "<div class='row mt-3'><div class='col-5'></div><div class='col-2'><a href='#' onclick='montarurl(\"{$lista->getId()}\",\"{$scoord}\");' class='btn btn-info mr-2 btn-sm'><i class='fa fa-route mr-1'></i>Ver Ruta en Mapa</a></div><div class='col-5'></div></div>";
            echo "</div>";            
        }
    }    
    ?>    
</div>
</body>
</html>