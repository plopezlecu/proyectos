<?php

// Si no tiene id lo mandamos a la página de repartos
if (!isset($_GET['id'])) {
    header('Location:repartos.php');
    die();
}

// recogemos la variable id y scoord del get
$id = $_GET['id'];
$scoord = $_GET['scoord'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Rutas</title>
    <!-- control que nos permite dibujar el mapa -->
    <script src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
    <!-- funciones javascript que usaremos -->
    <script type="text/javascript" src="../js/funciones.js"></script>   
</head>
<?php
// Para que sea inmediato dibujamos la ruta en el onload (llamamos a la función javascript que lo dibuja)
// le pasamos el id y las coordenadas
echo "<body style='background:#00bfa5;' onload=\"dibujarRuta('{$id}','{$scoord}');\">";
?>
<div class="container mt-3">
    <div class="d-flex justify-content-center h-100">
        <div class="card" style='width:80rem;height:50rem'>
            <div class="card-header"></div>            
            <div class="card-body">                
                <div class="form-group mt-1">
                    <!-- Div donde dibujaremos el mapa. Le he dado unos estilos para que se vea mejor -->
                    <div id="myMap" style='position:relative;width:67rem;height:42rem;'></div>
                </div>                  
                <div class="form-group">
                    <input type="hidden" name="idLTarea" value="<?php echo $id; ?>">
                    <a href="repartos.php" class="btn btn-success">Volver</a>
                </div>                
            </div>
        </div>
    </div>
</div>
<?php
echo "</body>";
?>
</html>