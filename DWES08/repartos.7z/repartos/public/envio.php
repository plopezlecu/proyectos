<?php

// Si no tiene id lo mandamos a la página de repartos
if (!isset($_GET['id'])) {
    header('Location:repartos.php');
    die();
}

// recogemos la variable id del get
$id = $_GET['id'];

// Usaremos la clase productos para listarlos
require '../src/Producto.php';

// recogemos la lista de productos existentes
$productos=new Producto();
$todos=$productos->listadoProductos();

// Incluimos las librerias Xajax
require '../src/xajax_core/xajax.inc.php';

//Creamos objeto AJAX, con la ruta donde estará el código
$xajax = new xajax('../src/Tools.php');

// Registramos la función. Se creará la función xajax_Votar para utilizar desde javascript
$xajax->register(XAJAX_FUNCTION, 'getCoordenadas');

// Configuramos el acceso a la carpeta xajax_js
$xajax->configure('javascript URI', '../src/');
$xajax->configure('debug', false); //si queremos debug
// El método processRequest procesa las peticiones que llegan a la página
// Debe ser llamado antes del código HTM
$xajax->processRequest();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Envio</title>
    <?php $xajax->printJavascript(); ?>
    <!-- funciones javascript que usaremos -->
    <script type="text/javascript" src="../js/funciones.js"></script>
</head>

<body style="background:#00bfa5;">
<div class="container mt-3">
    <div class="d-flex justify-content-center h-100">
        <div class="card" style='width:28rem;'>
            <div class="card-header">
                <h3><i class="fas fa-cart-plus mr-2"></i>Crear Envio</h3>
            </div>
            <div class="card-body">
                <form name="f1" method='POST' action='repartos.php'>
                    <div class="input-group form-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" style="width:2.5rem;"><i class="fas fa-city"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Dirección" id='dir' name='dir' required>
                    </div>
                    <div class="form-group mt-1">
                        <button class="btn btn-info mr-2" id="vDireccion" onclick="getCoordenadas();">Ver Coordenadas</button>
                    </div>
                    <div class="input-group form-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Latitud" id='lat' required name='lat' readonly>
                    </div>
                    <div class="input-group form-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="longitud" id='lon' name='lon' required readonly>
                    </div>
                    <!-- He añadido el apartado de la altitud -->
                    <div class="input-group form-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-info"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="altitud" id='alt' name='alt' required readonly>
                    </div>          
                    <!-- He cambiado el text por un select donde cargue los productos -->
                    <div class="input-group form-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-box-open"></i></span>
                        </div>                        
                        <select id="pro" name="pro" class="form-control" required>
                            <option value=""></option>
                        <?php  // Vamos dibujando los option con los productos
                        while($item=$todos->fetch(PDO::FETCH_OBJ)){?>                                                                               
                            <option value="<?php echo $item->nombre; ?>"><?php echo $item->nombre ?></option>
                        <?php }?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="idLTarea" value="<?php echo $id; ?>">
                        <input type='submit' class="btn btn-info mr-2" id="vDireccion" value="Nuevo Envio">
                        <a href="repartos.php" class="btn btn-success">Volver</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>

</html>