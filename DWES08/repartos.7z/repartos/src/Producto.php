<?php
require 'Conexion.php';

class Producto extends Conexion
{
    private $id;
    private $nombre;
    private $nombre_corto;
    private $pvp;
    private $famila;
    private $descripcion;

    /**
     * Producto constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * @param
     * @return listado de los productos seleccionados
     */
    public function listadoProductos()
    {
        $consulta = "SELECT productos.id,productos.nombre,IFNULL(count(votos.cantidad), 0) as votos
                     FROM productos left join votos on productos.id=votos.idPr group by id";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos " . $ex->getMessage());
        }
        return $stmt;
    }   
}
?>