<?php
require 'xajax_core/xajax.inc.php';
require 'Coordenadas.php';
$xajax = new xajax();

$xajax->register(XAJAX_FUNCTION, 'ordenarEnvios');
$xajax->register(XAJAX_FUNCTION, 'getCoordenadas');

$xajax->processRequest();

function getCoordenadas($dir)
{
    $resp = new xajaxResponse();
    $dir = trim($dir);
    if (strlen($dir) < 4) {
        $resp->setReturnValue(false);
        return $resp;
    }
    // En el constructor nos devolverá las 3 coordenadas
    // latitud, longitud y altitud en un array
    $c = new Coordenadas($dir);
    $lat = $c->getCoordenadas()[0];
    $lon = $c->getCoordenadas()[1];
    $alt = $c->getCoordenadas()[2];
    // lo mandamos a pantalla
    $resp->assign('lat', 'value', $lat);
    $resp->assign('lon', 'value', $lon);
    $resp->assign('alt', 'value', $alt);

    $resp->setReturnValue(true);
    
    return $resp;
}

// Devuelve los envíos ordenados, ya estaba hecho
function ordenarEnvios($puntos)
{
    $resp = new xajaxResponse();
    if (strlen(trim($puntos)) == 0) {
        $resp->setReturnValue(false);
        return $resp;
    }
    $c = new Coordenadas();
    $datos = $c->ordenarEnvios($puntos);
    $resp->setReturnValue($datos);
    return $resp;
}