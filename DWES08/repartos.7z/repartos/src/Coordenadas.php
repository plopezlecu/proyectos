<?php

class Coordenadas
{
    // Esta es la ruta que nos venía, de Almería. Le he puesto mi key
    public static $iniciourl = "http://dev.virtualearth.net/REST/v1/Locations/ES/Almeria/";
    public static $finurl = "?include=ciso2&maxResults=1&c=es&key=Ap-v-7HC0Bq3a0FaT1CAco5TeRYzsI69m0Luq_4jmYApGw9r4FVWweYXyF4dipQC";
    // Aquí he incluido la ruta para obtener la altitud. Le he puesto mi key
    public static $iniciourla = "http://dev.virtualearth.net/REST/v1/Elevation/List?";
    public static $finurla = "&heights=sealevel&key=Ap-v-7HC0Bq3a0FaT1CAco5TeRYzsI69m0Luq_4jmYApGw9r4FVWweYXyF4dipQC";
    public $coordenadas;
    public $url;
    public $urla; // Aquí montaremos la ruta de la altitud

     /**
     * Coordenadas constructor.
     */
    public function __construct()
    {
        $num = func_num_args(); // Devuelve el número de argumentos pasados a la función
        if ($num == 1) {
            // Para controlar los espacios
            $dir = str_replace(" ", "%20", func_get_arg(0)); //devuelve un elemento de una lista de argumentos
            $this->url = self::$iniciourl . "$dir" . self::$finurl;            
        }        
    }

    /*
     * @param
     * @return array con la latitud, longitud y altitud
     */
    public function getCoordenadas()
    {
        // Lee el fichero que nos devuelve la llamada
        $salida = file_get_contents($this->url); // Transmite un fichero completo a una cadena
        $salida1 = json_decode($salida, true);  // Decodifica un string de JSON, true lo pasa a array
        $latlon = $salida1["resourceSets"][0]["resources"][0]["point"]["coordinates"];

        // Monto la url para que nos devuelva la altitud con los datos de la latitud y longitud
        $this->urla = self::$iniciourla . "points=" . $latlon[0] . "," . $latlon[1] . self::$finurla;
        $salida2 = file_get_contents($this->urla);
        $salida3 = json_decode($salida2, true);
        // la devuelvo en la variable alt junto con la latitud y longitud
        $alt = $salida3["resourceSets"][0]["resources"][0]["elevations"][0];

        return array($latlon[0],$latlon[1],$alt);
    }

    // Esta función no la he tocado, venía tal cual
    // Nos ordena los envíos que se pasan por parámetro    
    public function ordenarEnvios($dato)
    {
        //Ponemos las coordenadas del alamacen por ejemplo '36.86071,-2440779' como inicio y fin de la ruta
        $base = "http://dev.virtualearth.net/REST/v1/Routes/driving?c=es&wayPoint.0=36.86071,-2.440779&";
        $puntos = explode("|", $dato);
        $num = 1;
        $trozo = "";
        for ($i = 0; $i < count($puntos); $i++) {
            $trozo .= "wayPoint." . $num++ . "=" . $puntos[$i] . "&";
        }
        $trozo .= "wayPoint." . $num . "=36.86071,-2.440779&optimize=distance&optWp=true&routeAttributes=routePath&key=Ap-v-7HC0Bq3a0FaT1CAco5TeRYzsI69m0Luq_4jmYApGw9r4FVWweYXyF4dipQC";
        $url = $base . $trozo;
        $salida = file_get_contents($url);
        $salida1 = json_decode($salida, true);
        $wayp = $salida1["resourceSets"][0]["resources"][0]['waypointsOrder'];
        //quitamos el primero y el ultimo (inicio y fin) (El almacen)
        array_shift($wayp);
        array_pop($wayp);

        for ($i = 0; $i < count($wayp); $i++) {
            $resp[] = substr(strstr($wayp[$i], '.'), 1);
        }
        return $resp;
    }    
}

