
function montarurl(lista,vsesion){                     
    window.location.href = 'ruta.php?id='+lista+'&scoord='+vsesion;
}

function dibujarMapa()
{         
    var lat = document.getElementById('lat').value;
    var lon = document.getElementById('lon').value;        
    var container = document.getElementById('lbm-map');    

    var map = new Microsoft.Maps.Map(container, {
        credentials: 'Ap-v-7HC0Bq3a0FaT1CAco5TeRYzsI69m0Luq_4jmYApGw9r4FVWweYXyF4dipQC',
        center: new Microsoft.Maps.Location(lat, lon),
        mapTypeId: Microsoft.Maps.MapTypeId.road,
        zoom: 15
    });   

    /* create a pushpin with pin options*/
	var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(lat,lon));
	pin.setOptions( 
	{ 
		width: 32, 
		height: 32,
		visible : true,
	});
	   		
	/* add pushpin to entry list */
	map.entities.push(pin);

}               

function getCoordenadas() {
    var dir = document.getElementById('dir').value;
    var res = xajax.request({xjxfun: 'getCoordenadas'}, {mode: 'synchronous', parameters: [dir]});
    if (res == false) {
        alert("Coordenada erróneas, revíselas");
    }
    return res;
}

function ordenarEnvios(id) {
    var puntos = $("#" + id + " input:hidden").map(function () {
        return this.value;
    }).get().join("|");
    var respuesta = xajax.request({xjxfun: "ordenarEnvios"}, {mode: 'synchronous', parameters: [puntos]});
    if (respuesta == false) {
        alert("No se pudo ordenar el envio");
        return respuesta;
    }
    // Si obtuvimos una respuesta, reordenamos los envíos del reparto
    // Cogemos la URL base del documento, quitando los parámetros GET si los hay
    var url = "http://localhost/TareaDWES08/repartos/public/repartos.php";               
    // Añadimos el código de la lista de reparto
    url += '?action=oEnvios&idLt=' + id;
    // Y un array con las nuevas posiciones que deben ocupar los envíos
    for (var r in respuesta) url += '&pos[]=' + respuesta[r];
    window.location = url;
}

function dibujarRuta(id,scoord) {    
    console.log("id " + id + " scoord " + scoord);
    var acoord = scoord.split('@');    
    acoord.forEach( function(valor, indice, array) {    
        valor1 =  valor.split(',');
        console.log("En el índice " + indice + " hay este valor: " + valor1[0] + " "+valor1[1] );
    });     
    
    //var arrayloc1 = [ [36.84009552001953, -2.4679040908813477], [36.84009552001953, -2.4679040908813477], [36.85276425154896, -2.450448982708787], [36.85596636633613, -2.4461851634416445] ]
    // La primera será la del almacén
    var valor1 =  acoord[0].split(',');
    var directionsManager;    
    var map = new Microsoft.Maps.Map('#myMap', {
            credentials: 'Ap-v-7HC0Bq3a0FaT1CAco5TeRYzsI69m0Luq_4jmYApGw9r4FVWweYXyF4dipQC',
            center: new Microsoft.Maps.Location(valor1[0], valor1[1]),
            mapTypeId: Microsoft.Maps.MapTypeId.road,                
    });

    //Load the directions module.
    Microsoft.Maps.loadModule('Microsoft.Maps.Directions', function () {
        //Create an instance of the directions manager.
        directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);                

        var waypoint;
        acoord.forEach( function(valor, indice, array) {            
            //Create waypoints to route between.
            valor1 =  valor.split(',');
            waypoint = new Microsoft.Maps.Directions.Waypoint({ location: new Microsoft.Maps.Location(valor1[0],valor1[1]) });
            directionsManager.addWaypoint(waypoint);
        }); 
        directionsManager.setRequestOptions({ routeOptimization: 'shortestDistance' });

        //Calculate directions.
        directionsManager.calculateDirections();
    });    
}
